<?php

function showAds1()
{
    ?>    
    <!-- Codegit_wide -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:728px;height:90px"
         data-ad-client="ca-pub-<?php echo $GLOBALS['config']['adsensPublishKey']?>"
         data-ad-slot="5852474725"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>        
    <?php
}
function showAds2()
{
    ?>        
    <!-- Codesgit_box -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:300px;height:250px"
         data-ad-client="ca-pub-<?php echo $GLOBALS['config']['adsensPublishKey']?>"
         data-ad-slot="5712873928"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>   
    <?php
}