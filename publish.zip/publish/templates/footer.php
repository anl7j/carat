<?php if(!empty($config)) { ?>
        <div class="row text-center visible-lg">
            <?php showAds1()?>
        </div>
    </div>
<?php } ?>
    
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
    </body>
</html>