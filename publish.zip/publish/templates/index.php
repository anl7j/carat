<?php 
include_once 'adsense.php';
include_once 'header.php'; ?>                 
            <?php 
            run();            
            ?>        
<?php include_once 'footer.php'; ?>