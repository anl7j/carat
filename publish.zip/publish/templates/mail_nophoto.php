Dear {name},
{senderName} has send you this card:

{imgPath}

Please find attached