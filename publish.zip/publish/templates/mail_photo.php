<h2>Dear {name}</h2>,
<div>{senderName} has send you this card: <br /></div>
<img src="{imgPath}" width="100%" />
<div><a href="{imgPath}">Click here if you can't see the image</a></div>